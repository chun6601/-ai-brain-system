"""AI Brain System - REST API（雲端版）"""
import json,sqlite3,hashlib,os,sys,time
from datetime import datetime
from functools import wraps
from flask import Flask,request,jsonify,g

sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DB_PATH=os.environ.get("DB_PATH","/tmp/brain.db")
os.makedirs(os.path.dirname(DB_PATH) if os.path.dirname(DB_PATH) else ".",exist_ok=True)

from audit.audit_system import AuditLogger,CostTracker,HumanApprovalLogger,init_audit_db
from ontology.ontology import WeimingOntology,OntologyDB
from workflows.workflow_engine import (
    build_addwii_quotation_workflow,build_addwii_airquality_workflow,
    build_microjet_8d_workflow,build_microjet_dev_workflow,
    build_weiming_transaction_workflow,build_weiming_contract_review_workflow)
from core.ai_brain import AIBrain

app=Flask(__name__)
app.config["SECRET_KEY"]=os.environ.get("SECRET_KEY","ai-brain-2024")
init_audit_db(DB_PATH)
audit=AuditLogger(DB_PATH); cost=CostTracker(DB_PATH); approver=HumanApprovalLogger(DB_PATH)

ROLES={"supervisor":{"level":4},"agent":{"level":3},"auditor":{"level":1}}
VALID_TOKENS={
    os.environ.get("SUPERVISOR_TOKEN","SUPERVISOR_TOKEN_001"):{"role":"supervisor","user":"参赛者"},
    "AGENT_TOKEN_SYS":{"role":"agent","user":"ai_system"},
    "AUDITOR_TOKEN_001":{"role":"auditor","user":"auditor_1"}}

def _init_db():
    conn=sqlite3.connect(DB_PATH)
    conn.execute("CREATE TABLE IF NOT EXISTS api_requests (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, method TEXT, path TEXT, user TEXT, role TEXT, status_code INTEGER, duration_ms INTEGER, ip TEXT)")
    conn.commit(); conn.close()
_init_db()

def require_auth(min_level=1):
    def decorator(f):
        @wraps(f)
        def wrapper(*args,**kwargs):
            token=request.headers.get("Authorization","").replace("Bearer ","")
            info=VALID_TOKENS.get(token)
            if not info: return jsonify({"error":"Unauthorized"}),401
            rl=ROLES.get(info["role"],{})
            if rl.get("level",0)<min_level: return jsonify({"error":f"Forbidden"}),403
            g.user=info["user"]; g.role=info["role"]; g.level=rl["level"]
            return f(*args,**kwargs)
        return wrapper
    return decorator

def log_req(f):
    @wraps(f)
    def wrapper(*args,**kwargs):
        t0=time.time(); resp=f(*args,**kwargs)
        ms=int((time.time()-t0)*1000)
        try:
            code=resp[1] if isinstance(resp,tuple) else 200
            conn=sqlite3.connect(DB_PATH)
            conn.execute("INSERT INTO api_requests (ts,method,path,user,role,status_code,duration_ms,ip) VALUES (?,?,?,?,?,?,?,?)",
                (datetime.utcnow().isoformat(),request.method,request.path,
                 getattr(g,"user","anon"),getattr(g,"role","none"),code,ms,request.remote_addr))
            conn.commit(); conn.close()
        except: pass
        return resp
    return wrapper

def tid(): return f"TASK_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{os.urandom(3).hex().upper()}"
def ok(data,code=200):
    data["_ts"]=datetime.utcnow().isoformat()
    return jsonify(data),code
def err(msg,code=400): return jsonify({"error":msg}),code

DASHBOARD_HTML = open(os.path.join(os.path.dirname(__file__),"dashboard.html"),encoding="utf-8").read() if os.path.exists(os.path.join(os.path.dirname(__file__),"dashboard.html")) else "<h1>AI Brain System Online</h1>"

@app.route("/")
def dashboard(): return DASHBOARD_HTML,200,{"Content-Type":"text/html; charset=utf-8"}

@app.route("/health")
def health():
    conn=sqlite3.connect(DB_PATH)
    tables=[r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    conn.close()
    return ok({"status":"online","mode":"online+offline_fallback","db_tables":tables,"offline_capable":True,"companies":["addwii","microjet","weiming"]})

@app.route("/addwii/quote",methods=["POST"])
@require_auth(2)
@log_req
def addwii_quote():
    body=request.json or {}
    if not body.get("customer_name"): return err("缺少 customer_name")
    t=tid()
    wf=build_addwii_quotation_workflow({"name":body["customer_name"],"type":body.get("type","一般家庭"),"spaces":body.get("spaces",["客廳"]),"budget":body.get("budget",150000)})
    result=wf.run(run_id=t); audit.log(t,"addwii","PRODUCT","產品規劃Agent","L2","generate_quote",getattr(g,"user","system"),body)
    cost.record(t,"addwii","PRODUCT","rule_engine",800,1200,4.0); ctx=wf.context
    return ok({"task_id":t,"customer":body["customer_name"],"workflow":result["status"],"quotation":ctx.get("s4",{}),"devices":ctx.get("s3",{}).get("devices",[]),"timeline":ctx.get("s6",{}).get("timeline",[]),"steps_completed":f"{result['steps_completed']}/{result['steps_total']}","audit_logged":True})

@app.route("/addwii/airquality",methods=["POST"])
@require_auth(2)
@log_req
def addwii_air():
    body=request.json or {}
    sensor={"pm25":body.get("pm25",0),"voc":body.get("voc",0),"co2":body.get("co2",0)}
    t=tid(); wf=build_addwii_airquality_workflow(sensor); result=wf.run(run_id=t)
    audit.log(t,"addwii","AIRQUALITY","空氣品質閉環Agent","L3","air_quality_loop",getattr(g,"user","system"),sensor)
    cost.record(t,"addwii","AIRQUALITY","rule_engine",200,400,0.5); ctx=wf.context
    return ok({"task_id":t,"readings":sensor,"assessment":ctx.get("s2",{}),"action":ctx.get("s3",{}).get("command"),"notification":ctx.get("s4",{}).get("message"),"audit_logged":True})

@app.route("/microjet/8d",methods=["POST"])
@require_auth(2)
@log_req
def microjet_8d():
    body=request.json or {}
    if not body.get("defect_type"): return err("缺少 defect_type")
    t=tid(); wf=build_microjet_8d_workflow(body); result=wf.run(run_id=t)
    audit.log(t,"microjet","QA","品保稽核Agent","L2","generate_8d",getattr(g,"user","system"),body)
    cost.record(t,"microjet","QA","rule_engine",600,1000,3.0); ctx=wf.context
    report={f"D{i}":ctx.get(f"D{i}",{}) for i in range(1,9)}
    return ok({"task_id":t,"defect_type":body["defect_type"],"8d_report":report,"customer_reply":ctx.get("D8",{}).get("customer_reply",""),"workflow":result["status"],"audit_logged":True})

@app.route("/microjet/dev",methods=["POST"])
@require_auth(2)
@log_req
def microjet_dev():
    body=request.json or {}
    t=tid(); wf=build_microjet_dev_workflow(body); result=wf.run(run_id=t)
    audit.log(t,"microjet","CEO","首席協調官","L3","dev_workflow",getattr(g,"user","system"),body); ctx=wf.context
    return ok({"task_id":t,"prd":ctx.get("s1",{}),"dev_plan":ctx.get("s2",{}),"test_plan":ctx.get("s3",{}),"patent_risk":ctx.get("s4",{}),"cost_estimate":ctx.get("s6",{}),"workflow":result["status"],"audit_logged":True})

@app.route("/weiming/transaction",methods=["POST"])
@require_auth(2)
@log_req
def weiming_tx():
    body=request.json or {}
    amount=body.get("amount_ntd",0); wallet=body.get("wallet_type","hot")
    t=tid(); wf=build_weiming_transaction_workflow(body); result=wf.run(run_id=t)
    audit.log(t,"weiming","TRADE","交易Agent","L3","process_transaction",getattr(g,"user","system"),body)
    ctx=wf.context; risk=ctx.get("s3",{}); is_blocked=risk.get("risk_level")=="L4"
    if is_blocked: approver.record_approval(t,t+"_L4","TRADE",f"交易NT${amount:,}({wallet}錢包)","L4","PENDING","pending","等待人工審核")
    return ok({"task_id":t,"amount_ntd":amount,"wallet_type":wallet,"blocked":is_blocked,"status":"需人工審核（L4已攔截）" if is_blocked else "自動執行完成","tx_hash":ctx.get("s6",{}).get("tx_hash") if not is_blocked else None,"audit_logged":True})

@app.route("/weiming/contract/review",methods=["POST"])
@require_auth(2)
@log_req
def weiming_contract():
    body=request.json or {}
    t=tid(); wf=build_weiming_contract_review_workflow(body); result=wf.run(run_id=t)
    audit.log(t,"weiming","CONTRACT","合約審查Agent","L1","contract_review",getattr(g,"user","system"),{"contract":body.get("name","unnamed")}); ctx=wf.context
    return ok({"task_id":t,"scan_result":ctx.get("s1",{}),"recommendation":ctx.get("s3",{}).get("deploy_recommendation"),"auto_deploy_blocked":True,"human_approval_required":True,"audit_logged":True})

@app.route("/audit/trace/<task_id>")
@require_auth(1)
def audit_trace(task_id): return ok({"task_id":task_id,"trace":audit.get_task_trace(task_id)})

@app.route("/audit/verify/<company>")
@require_auth(1)
def audit_verify(company): return ok(audit.verify_chain(company))

@app.route("/audit/summary/<company>")
@require_auth(1)
def audit_summary(company): return ok(audit.get_company_summary(company))

@app.route("/cost/daily/<company>")
@require_auth(1)
def cost_daily(company): return ok(cost.get_daily_report(company,request.args.get("date")))

@app.route("/human/pending")
@require_auth(4)
def human_pending(): return ok({"pending_l4":approver.list_pending_l4()})

@app.route("/human/approve",methods=["POST"])
@require_auth(4)
def human_approve():
    body=request.json or {}
    if not all(k in body for k in ["task_id","exec_id","decision"]): return err("缺少欄位")
    sig=approver.record_approval(body["task_id"],body["exec_id"],body.get("agent_id",""),body.get("action",""),"L4",g.user,body["decision"],body.get("reason",""))
    return ok({"approved":body["decision"]=="approve","signature":sig,"approver":g.user})

if __name__=="__main__":
    port=int(os.environ.get("PORT",5000))
    app.run(host="0.0.0.0",port=port,debug=False)
