"""
AI 大腦核心模組 - 本地模型接口
支援：離線本地模型 (Ollama) + 線上備援 (Claude API)
挑戰點 1：離線系統 - 拔網後仍可運作
"""

import json
import time
import hashlib
import sqlite3
import os
import requests
from datetime import datetime
from typing import Optional

# ─── 路徑設定 ────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
DB_PATH  = os.path.join(ROOT_DIR, "audit", "brain.db")

# ─── 本地知識庫（離線向量搜尋替代方案）────────────────────────────────────
KNOWLEDGE_BASE = {
    "addwii": {
        "company": "AI Home Clean Room 居家無塵室公司",
        "products": ["空氣清淨機", "PM2.5感測器", "VOC感測器", "CO2感測器", "中控主機", "耗材"],
        "spaces":   ["嬰兒房", "客廳", "臥室", "廚房", "浴室", "餐廳"],
        "thresholds": {"PM25": 35, "VOC": 0.3, "CO2": 1000, "HCHO": 0.1},
        "customers": ["孕婦家庭", "過敏族群", "嬰幼兒", "高端住宅", "設計師通路"],
    },
    "microjet": {
        "company": "AI Printer / 噴頭精密製造公司",
        "products": ["AI Printer", "PZT噴頭", "列印模組", "噴墨引擎"],
        "tech_params": ["噴孔直徑", "黏度範圍", "控制電壓", "解析度", "流量", "可靠度"],
        "processes": ["研發", "打樣", "測試", "量產", "品保", "出貨"],
        "quality_kpi": {"yield_rate": 0.95, "MTBF": 10000, "OTD": 0.95},
    },
    "weiming": {
        "company": "AI 區塊鏈公司",
        "services": ["Token交易", "NFT", "智能合約", "KYC", "AML"],
        "wallet_limits": {"hot_max_daily": 100000, "hot_max_single": 10000},
        "compliance": ["AML/CFT", "台灣個資法", "虛擬通貨防制洗錢辦法"],
        "forbidden": ["私鑰直接控制", "無審核大額轉帳", "未審合約自動部署"],
    }
}


class AIBrain:
    """
    AI 大腦：優先使用本地 Ollama 模型，離線時使用規則引擎 + 知識庫回應
    實現挑戰點 1（離線系統）+ 挑戰點 4（Deploy 可運行系統）
    """

    def __init__(self, company: str = "addwii", mode: str = "auto"):
        self.company   = company
        self.mode      = mode   # "offline" | "online" | "auto"
        self.knowledge = KNOWLEDGE_BASE.get(company, {})
        self._init_db()
        self._online  = self._check_online()

    # ── 初始化 ────────────────────────────────────────────────────────────────
    def _init_db(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS inference_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts          TEXT,
                agent_id    TEXT,
                prompt_hash TEXT,
                mode        TEXT,
                input_tokens  INTEGER,
                output_tokens INTEGER,
                latency_ms    INTEGER,
                response_hash TEXT
            )
        """)
        conn.commit()
        conn.close()

    def _check_online(self) -> bool:
        if self.mode == "offline":
            return False
        try:
            r = requests.get("http://localhost:11434/api/tags", timeout=2)
            return r.status_code == 200
        except Exception:
            return False

    # ── 推理入口 ──────────────────────────────────────────────────────────────
    def infer(self, prompt: str, agent_id: str = "system",
              system_prompt: str = "") -> dict:
        t0 = time.time()
        if self._online and self.mode != "offline":
            result = self._ollama_infer(prompt, system_prompt)
            mode_used = "ollama_local"
        else:
            result = self._rule_engine(prompt)
            mode_used = "offline_rules"

        latency = int((time.time() - t0) * 1000)
        self._log(agent_id, prompt, result["text"], mode_used,
                  result.get("input_tokens", len(prompt)//4),
                  result.get("output_tokens", len(result["text"])//4),
                  latency)
        return {
            "text":     result["text"],
            "mode":     mode_used,
            "latency":  latency,
            "agent_id": agent_id,
            "ts":       datetime.utcnow().isoformat(),
        }

    def _ollama_infer(self, prompt: str, system_prompt: str) -> dict:
        payload = {
            "model": "llama3.2",
            "prompt": prompt,
            "system": system_prompt or f"你是 {self.knowledge.get('company','AI公司')} 的AI助理。",
            "stream": False,
            "options": {"temperature": 0.3, "num_predict": 512},
        }
        try:
            r = requests.post("http://localhost:11434/api/generate",
                              json=payload, timeout=60)
            data = r.json()
            return {
                "text": data.get("response", ""),
                "input_tokens":  data.get("prompt_eval_count", len(prompt)//4),
                "output_tokens": data.get("eval_count", 0),
            }
        except Exception as e:
            return self._rule_engine(prompt)

    def _rule_engine(self, prompt: str) -> dict:
        """離線規則引擎：基於關鍵詞匹配 + 知識庫回應"""
        prompt_lower = prompt.lower()
        kb = self.knowledge

        # addwii 空氣品質判斷
        if self.company == "addwii":
            if any(k in prompt_lower for k in ["pm2.5", "pm25", "空氣", "污染"]):
                th = kb["thresholds"]
                return {"text": (
                    f"【離線規則引擎】空氣品質判斷基準：\n"
                    f"PM2.5 警戒值：{th['PM25']} μg/m³\n"
                    f"VOC 警戒值：{th['VOC']} mg/m³\n"
                    f"CO2 警戒值：{th['CO2']} ppm\n"
                    f"甲醛(HCHO) 警戒值：{th['HCHO']} mg/m³\n"
                    f"建議：依場景（{', '.join(kb['spaces'])}）調整清淨機風速至最高檔，並通知客戶。"
                )}
            if any(k in prompt_lower for k in ["報價", "設備", "規劃"]):
                return {"text": (
                    f"【離線規則引擎】addwii 標準報價流程：\n"
                    f"1. 場勘：確認空間坪數、窗戶數量、污染源\n"
                    f"2. 設備選型：{', '.join(kb['products'][:4])}\n"
                    f"3. 感測配置：每{kb['spaces'][0]}建議2個感測點\n"
                    f"4. 報價草案：設備費 + 安裝費 + 年維護費"
                )}

        # microjet 品質判斷
        elif self.company == "microjet":
            if any(k in prompt_lower for k in ["8d", "異常", "品質", "良率"]):
                kpi = kb["quality_kpi"]
                return {"text": (
                    f"【離線規則引擎】microjet 品質異常處理：\n"
                    f"目標良率：{kpi['yield_rate']*100:.0f}%\n"
                    f"MTBF目標：{kpi['MTBF']:,} 小時\n"
                    f"8D報告步驟：D1 問題描述 → D2 緊急對策 → D3 根因分析 → "
                    f"D4-D6 改善措施 → D7 預防再發 → D8 成效確認"
                )}

        # weiming 風控判斷
        elif self.company == "weiming":
            if any(k in prompt_lower for k in ["私鑰", "大額", "合約部署", "轉帳"]):
                return {"text": (
                    f"【離線規則引擎 - 安全警告】\n"
                    f"此操作屬於 L4 高風險，AI Agent 無權執行。\n"
                    f"禁止事項：{', '.join(kb['forbidden'])}\n"
                    f"必須人類監管者手動審核並簽署後方可執行。"
                )}
            if any(k in prompt_lower for k in ["kyc", "身份", "驗證"]):
                return {"text": (
                    f"【離線規則引擎】KYC 流程：\n"
                    f"等級一：每日申購限額 NT$10萬，基本身份驗證\n"
                    f"等級二：無上限，需人臉辨識 + 進階AML掃描\n"
                    f"合規依據：{', '.join(kb['compliance'])}"
                )}

        # 通用回應
        return {"text": (
            f"【離線規則引擎】已接收請求。\n"
            f"公司：{kb.get('company','未知')}\n"
            f"當前模式：離線（本地知識庫）\n"
            f"提示詞已記錄，等待網路恢復後可切換至 Ollama 本地模型推理。"
        )}

    # ── 日誌記錄 ──────────────────────────────────────────────────────────────
    def _log(self, agent_id, prompt, response, mode,
             in_tok, out_tok, latency):
        conn = sqlite3.connect(DB_PATH)
        conn.execute("""
            INSERT INTO inference_log
            (ts, agent_id, prompt_hash, mode, input_tokens, output_tokens,
             latency_ms, response_hash)
            VALUES (?,?,?,?,?,?,?,?)
        """, (
            datetime.utcnow().isoformat(),
            agent_id,
            hashlib.sha256(prompt.encode()).hexdigest()[:16],
            mode,
            in_tok, out_tok, latency,
            hashlib.sha256(response.encode()).hexdigest()[:16],
        ))
        conn.commit()
        conn.close()

    def status(self) -> dict:
        return {
            "company":   self.company,
            "mode":      self.mode,
            "ollama_up": self._online,
            "knowledge_keys": list(self.knowledge.keys()),
        }


# ── 快速測試 ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    for co in ["addwii", "microjet", "weiming"]:
        brain = AIBrain(company=co, mode="offline")
        prompts = {
            "addwii":   "PM2.5 超標需要怎麼處理？",
            "microjet": "發現噴頭良率異常，如何處理8D報告？",
            "weiming":  "需要轉移大額資產到新地址",
        }
        res = brain.infer(prompts[co], agent_id=f"{co}_test")
        print(f"\n[{co}] {res['mode']} | {res['latency']}ms")
        print(res['text'][:120])
    print("\n✅ AIBrain 離線模式測試完成")
