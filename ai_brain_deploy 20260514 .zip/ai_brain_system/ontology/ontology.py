"""
業務本體（Ontology）框架
挑戰點 1 & 4：定義三家公司的人、物、流程、狀態、動作
讓 Agent 在可控業務物件上工作，而非只是聊天
"""

import json
import sqlite3
import os
from datetime import datetime
from typing import Any, Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
DB_PATH  = os.path.join(ROOT_DIR, "audit", "brain.db")


# ─── 本體物件基類 ─────────────────────────────────────────────────────────────
class OntologyObject:
    def __init__(self, oid: str, obj_type: str, company: str, props: dict):
        self.oid      = oid
        self.obj_type = obj_type
        self.company  = company
        self.props    = props
        self.state    = "active"
        self.created  = datetime.utcnow().isoformat()
        self.history  = []

    def update(self, key: str, value: Any, actor: str):
        old = self.props.get(key)
        self.props[key] = value
        self.history.append({
            "ts": datetime.utcnow().isoformat(),
            "actor": actor, "key": key,
            "old": old, "new": value,
        })

    def to_dict(self) -> dict:
        return {
            "oid": self.oid, "type": self.obj_type,
            "company": self.company, "props": self.props,
            "state": self.state, "created": self.created,
            "history_count": len(self.history),
        }


# ─── addwii Ontology ──────────────────────────────────────────────────────────
class AddwiiOntology:
    """
    addwii 業務本體：空間、感測資料、設備、客戶、流程、風險
    """
    @staticmethod
    def create_customer(cid: str, name: str, customer_type: str,
                        address: str, spaces: list) -> OntologyObject:
        return OntologyObject(cid, "Customer", "addwii", {
            "name": name,
            "type": customer_type,   # 孕婦家庭/過敏族群/嬰幼兒/高端住宅
            "address": address,
            "spaces": spaces,        # 要安裝的空間列表
            "status": "prospect",    # prospect/contracted/installed/maintenance
            "pm25_baseline": None,
            "contract_value": 0,
        })

    @staticmethod
    def create_space(sid: str, customer_id: str,
                     space_type: str, area_m2: float) -> OntologyObject:
        return OntologyObject(sid, "Space", "addwii", {
            "customer_id": customer_id,
            "type": space_type,      # 嬰兒房/客廳/臥室/廚房/浴室/餐廳
            "area_m2": area_m2,
            "sensor_count": 0,
            "device_count": 0,
            "current_pm25": None,
            "current_voc": None,
            "current_co2": None,
            "alert_active": False,
        })

    @staticmethod
    def create_device(did: str, space_id: str,
                      device_type: str, model: str) -> OntologyObject:
        return OntologyObject(did, "Device", "addwii", {
            "space_id": space_id,
            "type": device_type,     # 空氣清淨機/感測器/中控主機
            "model": model,
            "status": "offline",     # offline/online/alert/maintenance
            "installed_at": None,
            "last_reading": None,
            "fan_speed": 0,          # 0-5
        })

    @staticmethod
    def create_service_order(oid: str, customer_id: str,
                             order_type: str) -> OntologyObject:
        return OntologyObject(oid, "ServiceOrder", "addwii", {
            "customer_id": customer_id,
            "type": order_type,      # 場勘/安裝/維護/緊急
            "status": "pending",     # pending/scheduled/in_progress/completed
            "scheduled_at": None,
            "technician": None,
            "checklist": [],
            "cost_estimate": 0,
        })

    @staticmethod
    def evaluate_air_quality(pm25: float, voc: float,
                             co2: float, hcho: float = 0) -> dict:
        """核心業務邏輯：空氣品質評估"""
        issues = []
        level  = "良好"
        if pm25 > 35:
            issues.append(f"PM2.5超標({pm25:.1f}>35μg/m³)")
            level = "警戒" if pm25 < 75 else "危險"
        if voc > 0.3:
            issues.append(f"VOC超標({voc:.2f}>0.3mg/m³)")
            level = "危險"
        if co2 > 1000:
            issues.append(f"CO2超標({co2:.0f}>1000ppm)")
            if level == "良好": level = "注意"
        if hcho > 0.1:
            issues.append(f"甲醛超標({hcho:.2f}>0.1mg/m³)")
            level = "危險"
        return {
            "level": level,
            "issues": issues,
            "action_required": len(issues) > 0,
            "recommended_fan_speed": 5 if level == "危險" else (3 if level == "警戒" else 1),
        }


# ─── microjet Ontology ────────────────────────────────────────────────────────
class MicrojetOntology:
    """
    microjet 業務本體：產品、技術參數、製程、品質、客戶、風險
    """
    @staticmethod
    def create_product(pid: str, name: str, product_type: str,
                       spec: dict) -> OntologyObject:
        return OntologyObject(pid, "Product", "microjet", {
            "name": name,
            "type": product_type,    # AI_Printer/噴頭/列印模組
            "spec": spec,            # 技術規格字典
            "status": "development", # development/testing/production/EOL
            "yield_rate": None,
            "mtbf_hours": None,
            "patent_risk": "unknown",
            "bom": [],
        })

    @staticmethod
    def create_defect_report(rid: str, product_id: str,
                             defect_type: str, description: str) -> OntologyObject:
        return OntologyObject(rid, "DefectReport", "microjet", {
            "product_id": product_id,
            "type": defect_type,     # 堵頭/漏墨/壽命不足/尺寸超差
            "description": description,
            "severity": "unknown",   # Critical/Major/Minor
            "status": "open",        # open/in_analysis/corrected/closed
            "d1_problem": description,
            "d2_containment": None,
            "d3_root_cause": None,
            "d4_corrective": None,
            "d8_closure": None,
            "customer_notified": False,
        })

    @staticmethod
    def create_test_plan(tid: str, product_id: str,
                         test_type: str) -> OntologyObject:
        return OntologyObject(tid, "TestPlan", "microjet", {
            "product_id": product_id,
            "type": test_type,       # 單元/整合/環境/壽命
            "status": "draft",
            "cases": [],
            "pass_criteria": {
                "yield_rate":  0.95,
                "mtbf":        10000,
                "otd":         0.95,
            },
            "result": None,
        })

    @staticmethod
    def generate_8d_template(defect_type: str) -> dict:
        """自動生成 8D 報告模板"""
        templates = {
            "堵頭": {
                "d1": "噴頭堵塞導致噴出品質不良",
                "d2": "立即停線，對受影響批次隔離",
                "d3": ["墨水黏度過高", "噴孔直徑公差超差", "清洗週期不足"],
                "d4": "調整墨水配方黏度至目標範圍，重新校正噴孔加工參數",
            },
            "漏墨": {
                "d1": "噴頭墨水滲漏影響列印品質與設備壽命",
                "d2": "更換密封件，對問題機台進行100%檢查",
                "d3": ["密封圈材質不適", "組裝扭力不足", "壓力設定過高"],
                "d4": "更換耐化學品密封圈，導入扭力管控作業標準",
            },
        }
        t = templates.get(defect_type, {
            "d1": f"{defect_type} 問題描述",
            "d2": "立即隔離受影響產品",
            "d3": ["待根因分析"],
            "d4": "待改善措施確認",
        })
        return {**t, "d5": "確認改善措施有效性", "d6": "標準化作業程序",
                "d7": "更新FMEA，預防類似問題", "d8": "客戶確認，結案"}


# ─── 維明 Ontology ────────────────────────────────────────────────────────────
class WeimingOntology:
    """
    維明業務本體：鏈上、鏈下、冷熱錢包、KYC、風控
    """
    WALLET_LIMITS = {
        "hot":  {"daily": 100_000, "single": 10_000},  # NT$
        "warm": {"requires_multisig": True, "min_signers": 2},
        "cold": {"ai_access": False, "requires_human_offline": True},
    }

    @staticmethod
    def create_customer(cid: str, name: str) -> OntologyObject:
        return OntologyObject(cid, "Customer", "weiming", {
            "name": name,
            "kyc_level": 0,          # 0=未驗證 1=基本 2=完整
            "daily_limit": 0,
            "aml_status": "pending", # pending/clear/flagged/blocked
            "wallet_address": None,
            "total_purchased": 0,
        })

    @staticmethod
    def create_transaction(tid: str, customer_id: str, currency: str,
                           amount_ntd: float, wallet_type: str = "hot") -> OntologyObject:
        return OntologyObject(tid, "Transaction", "weiming", {
            "customer_id": customer_id,
            "currency": currency,    # BTC/ETH/USDT
            "amount_ntd": amount_ntd,
            "wallet_type": wallet_type,
            "status": "pending",     # pending/locked/confirmed/failed/cancelled
            "risk_score": 0,         # 0-100
            "aml_checked": False,
            "block_hash": None,
            "requires_human": False,
        })

    @staticmethod
    def risk_check(tx_amount: float, wallet_type: str,
                   customer_aml: str, daily_used: float) -> dict:
        """風控邏輯：判斷交易是否需要人工審核"""
        limits  = WeimingOntology.WALLET_LIMITS
        reasons = []
        level   = "L2"  # 預設可執行

        # 1. AML 檢查
        if customer_aml in ("flagged", "blocked"):
            reasons.append("AML 警示客戶")
            level = "L4"

        # 2. 錢包類型檢查
        if wallet_type == "cold":
            reasons.append("冷錢包操作禁止AI執行")
            level = "L4"
        elif wallet_type == "warm":
            reasons.append("溫錢包需多簽審核")
            level = "L4"

        # 3. 金額限制檢查（熱錢包）
        if wallet_type == "hot":
            if tx_amount > limits["hot"]["single"]:
                reasons.append(f"單筆超限({tx_amount:,.0f} > {limits['hot']['single']:,})")
                level = "L4"
            if daily_used + tx_amount > limits["hot"]["daily"]:
                reasons.append("日額度超限")
                level = "L4"

        return {
            "level": level,
            "can_execute_auto": level != "L4",
            "requires_human":   level == "L4",
            "reasons": reasons,
            "action": "自動執行" if level != "L4" else "⛔ 停止 - 需人工批准",
        }

    @staticmethod
    def smart_contract_risk_scan(contract_code: str) -> dict:
        """智能合約靜態風險掃描（L1建議型，不自動部署）"""
        risks = []
        code  = contract_code.lower()
        if "selfdestruct" in code:
            risks.append({"type": "Critical", "name": "自毀函數", "desc": "合約可被強制銷毀"})
        if "tx.origin" in code:
            risks.append({"type": "High", "name": "身份驗證漏洞", "desc": "使用tx.origin可被釣魚攻擊"})
        if "call.value" in code or ".call{value" in code:
            risks.append({"type": "High", "name": "重入攻擊風險", "desc": "建議使用ReentrancyGuard"})
        if "overflow" not in code and "safeMath" not in code.replace(" ",""):
            risks.append({"type": "Medium", "name": "溢位風險", "desc": "建議使用SafeMath或Solidity 0.8+"})
        critical = sum(1 for r in risks if r["type"] == "Critical")
        high     = sum(1 for r in risks if r["type"] == "High")
        return {
            "total_issues": len(risks),
            "critical": critical, "high": high,
            "risks": risks,
            "deploy_recommendation": "禁止部署" if critical > 0 else (
                "需修復後部署" if high > 0 else "可部署（建議人工複審）"),
            "note": "此為 L1 建議報告，最終部署決策必須由人類監管者確認（L4）",
        }


# ─── 本體資料庫 ───────────────────────────────────────────────────────────────
class OntologyDB:
    """本體物件的持久化存儲"""
    def __init__(self, db_path: str = DB_PATH):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._init()

    def _init(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ontology_objects (
                oid TEXT PRIMARY KEY,
                obj_type TEXT, company TEXT,
                props TEXT, state TEXT,
                created TEXT, history TEXT
            )
        """)
        conn.commit(); conn.close()

    def save(self, obj: OntologyObject):
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            INSERT OR REPLACE INTO ontology_objects
            VALUES (?,?,?,?,?,?,?)
        """, (obj.oid, obj.obj_type, obj.company,
              json.dumps(obj.props, ensure_ascii=False),
              obj.state, obj.created,
              json.dumps(obj.history, ensure_ascii=False)))
        conn.commit(); conn.close()

    def get(self, oid: str) -> Optional[dict]:
        conn = sqlite3.connect(self.db_path)
        row  = conn.execute(
            "SELECT * FROM ontology_objects WHERE oid=?", (oid,)
        ).fetchone()
        conn.close()
        if row:
            return {"oid": row[0], "type": row[1], "company": row[2],
                    "props": json.loads(row[3]), "state": row[4]}
        return None

    def list_by_company(self, company: str) -> list:
        conn = sqlite3.connect(self.db_path)
        rows = conn.execute(
            "SELECT oid, obj_type, state, created FROM ontology_objects WHERE company=?",
            (company,)
        ).fetchall()
        conn.close()
        return [{"oid": r[0], "type": r[1], "state": r[2], "created": r[3]}
                for r in rows]


# ─── 快速測試 ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    db = OntologyDB()

    # addwii 測試
    cust = AddwiiOntology.create_customer(
        "C001", "王小明", "孕婦家庭", "台北市信義區", ["嬰兒房", "客廳"])
    db.save(cust)
    aq = AddwiiOntology.evaluate_air_quality(pm25=48.3, voc=0.2, co2=850)
    print(f"[addwii] 空氣品質：{aq['level']} | 問題：{aq['issues']}")

    # microjet 測試
    report = MicrojetOntology.create_defect_report(
        "D001", "P001", "堵頭", "第3批次噴頭大量堵塞")
    template = MicrojetOntology.generate_8d_template("堵頭")
    db.save(report)
    print(f"[microjet] 8D D3根因：{template['d3']}")

    # 維明 測試
    risk = WeimingOntology.risk_check(
        tx_amount=15000, wallet_type="hot",
        customer_aml="clear", daily_used=50000)
    print(f"[weiming] 風控結果：{risk['action']} | 原因：{risk['reasons']}")

    scan = WeimingOntology.smart_contract_scan = WeimingOntology.smart_contract_risk_scan
    result = scan("function withdraw() { msg.sender.call.value(balance)(); selfdestruct(owner); }")
    print(f"[weiming] 合約掃描：{result['deploy_recommendation']} | Critical:{result['critical']}")

    print("\n✅ Ontology 框架測試完成")
